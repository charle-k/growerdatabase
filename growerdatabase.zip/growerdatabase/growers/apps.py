from django.apps import AppConfig


class GrowersConfig(AppConfig):
    name = 'growers'
